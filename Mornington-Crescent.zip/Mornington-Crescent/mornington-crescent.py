from mc_controller import Controller

game = Controller()
game.run()